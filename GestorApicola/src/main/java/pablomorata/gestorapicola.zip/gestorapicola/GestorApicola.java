/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pablomorata.gestorapicola;

/**
 *
 * @author blitowsky
 */
public class GestorApicola {

    public static void main(String[] args) {
        
        Menu menu = new Menu();
        
        menu.elegirAcciones();
        
    }
}
